#!/bin/env bash

#$ -cwd
#$ -j y
#$ -o job_logs/$JOB_NAME.$JOB_ID
#$ -pe smp 32
#$ -mods l_hard mfree 64G

# Runs NCycProfiler against our reads using diamond

read_path=$1
if [ -z "$read_path" ]; then
    echo "Usage: $0 /path/to/fastq/dir"
    exit 1
fi

mkdir $TMPDIR/reads
cp -v $read_path/* $TMPDIR/reads
cp -vR $CONDA_PREFIX/NCyc/data $TMPDIR/
cd $TMPDIR
NCycProfiler.PL -d $TMPDIR/reads -m diamond -f fq.gz -s nucl -si si.txt -o ncyc.out
rm -rf $TMPDIR/reads
cd -
cp -Rv $TMPDIR/* .


