#!/bin/env bash

#$ -cwd
#$ -j y
#$ -o job_logs/$JOB_NAME.$JOB_ID

# Creates sample information file for NCycProfiler, which is a tab-delimited file
# containing the sample ID and the number of read(pairs) it contains.

read_path=$1
if [ -z "$read_path" ]; then
	echo "Usage: $0 /path/to/fastq/dir"
	exit 1
fi

for path in $(ls ${read_path}/*1.fq.gz); do
	sample=$(basename $path|sed 's/.fq.gz//')	
	echo -en "$sample\t" 
	echo $(zcat $path|wc -l)/4|bc
done
