# Metagenomic Analysis

The scripts and Jupyter/RMarkdown notebooks within these directories were used to carry out the analysis of the metagenomic sequences. They are divided up into 'logical' sections which need to be run in the correct order.

Each section includes a conda yaml file which can be used to recreate the correct software environment for running each analysis by running

`conda env create -f /path/to/config_file.yaml`

Some analysis are run as Snakemake workflows, in which case there is a bash wrapper script named `run_workflow.sh` which will launch these. Note that some of the configurations within the workflows and scripts relate to our HPC cluster, and will probably need adjusting to work in a different environment.

1. ncyc - NCycDB analysis (Supplementary Figure 3)
2. MAG_assembly - Assembly of metagenomic contigs, MAG reconstruction and abundance estimation (Supplementary Figure 5)
3. functional_annotation - InterProScan annotation of predicted metagenomic protein clusters, and quantitation. Note that the quantiation at this stage retains a proportion (~5%) of eukaryotic sequences which provide a confusing picture, hence these should not be relied upon
4. eukaryote_filter - filtering out eukaryote proteins by diamond alignment to uniprot, followed by requantification. Differential abundance was determined using DESeq2 in `MAG_eukaryote_screened_GO_enrichment.Rmd`, which also produces the PCA plots and k-means clustering in Figure 4 and Supplementary Figure 4. Additionally, the `GO_correlations.Rmd` was used to create Figure 5.


