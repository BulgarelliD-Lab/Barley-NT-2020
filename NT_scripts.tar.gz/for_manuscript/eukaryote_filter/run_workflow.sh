#!/bin/env bash
snakemake --rerun-incomplete --cluster-config config.json -k --latency-wait 60 -j 80 --jn euk_screen.{jobid} --cluster "qsub -cwd -j y -o logs/{rule}.{wildcards}.log -pe smp {cluster.threads} -jc short -mods l_hard mfree {cluster.mem_free} -adds l_hard local_free {cluster.disk_free}" 

