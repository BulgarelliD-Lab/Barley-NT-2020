#!/bin/env bash
snakemake --cluster-config config.json -k --latency-wait 60 -j 100 --jn interproscan.{jobid} --drmaa " -cwd -j y -o logs/{rule}.{wildcards}.log -jc {cluster.jc} -pe smp {cluster.threads} -mods l_hard mfree {cluster.mem_free} " 

