#!/bin/env bash

#$ -j y
#$ -o job_logs/$JOB_NAME.$JOB_ID
#$ -cwd

rm -rv /tmp/ipr_db
rm -v /tmp/ipr_db_present

